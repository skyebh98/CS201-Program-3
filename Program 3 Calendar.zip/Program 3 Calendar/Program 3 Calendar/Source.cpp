//Skye Hewitt
//sbhngh@mail.umkc.edu
//Program 3 - Calendar

#include <iostream>
#include <iomanip>
#include <string>


using namespace std;


//Function declarations

void PrintOneMonth(int year, int daysPerMonth, string month, int monthStartDays, int numberOfDays);
int GetYear();
int GetStartDayNumber();
int IsLeapYear(int year);
int DaysPerMonth(int year, int monthNumber, int numberOfDays);
int GetMonthStartDays(int startDayNumber, int numberOfDays, int monthStartDays[], int month, int dayCount);

//Structure definition

struct aboutYear {
	int year;
	int startDayNumber; //Start day
	int numberOfDays; //Is it a leap year?
	int daysPerMonth[12]; //First set is days per month, second set it the starting day
	int monthStartDays[12];
};


//Main program

int main() {
	aboutYear calendar;
	int index;
	int dayCount;
	string monthNames[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

	while(true) { //Using a while with continue and break statements, so if the user enters an invalid year/start day, this portion of the program restarts. 

		try {
			calendar.year = GetYear();
			calendar.startDayNumber = GetStartDayNumber();
			dayCount = calendar.startDayNumber; //Used when determining the start day for each month
			//Sunday : 0, Monday : 1, Tuesday : 2, Wednesday : 3, Thursday : 4, Friday : 5, Saturday : 6.
			calendar.numberOfDays = IsLeapYear(calendar.year);
		}
		catch (runtime_error excpt) {
			cout << excpt.what() << endl;
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			continue;
		}
		catch (...) {
			cout << endl << "Invalid input. ";
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			continue;
		}


		for (index = 0; index < 12; ++index) {

			//Getting input from user
			calendar.daysPerMonth[index] = DaysPerMonth(calendar.year, index, calendar.numberOfDays);
			cout << endl;
			calendar.monthStartDays[index] = GetMonthStartDays(calendar.startDayNumber, calendar.numberOfDays, calendar.monthStartDays, index, dayCount);
			cout << endl;

			dayCount += calendar.daysPerMonth[index];

			//Outputting calendar
			PrintOneMonth(calendar.year, calendar.daysPerMonth[index], monthNames[index], calendar.monthStartDays[index], calendar.numberOfDays);
			cout << endl << endl;

		}

		break; //If the end of the program is reached, the while loop is broken. 

	} 

	system("pause");

}

//Function definitions

int GetYear() {
	//Gets a year from the user and verifies that it is valid (1000-9999)
	int year;
	do {
		cout << "Enter a year to print. " << endl;
		cout << "(Must be a number between 1000 and 9999.) >> ";
		cin >> year;
		if (cin.fail()) {
			throw runtime_error("Year must be a number. \n");
		}
	} while (year < 1000 || year > 9999);

	return year;

}

int GetStartDayNumber() {
	/*Accepts of a string for the day of the week, capitalized or not,
	the first 3 letters or the full name, and returns the number of the day of the week. */
	string dayOfWeek;

	do {
		cout << "What day of the week does this year start with?" << endl;
		cout << "(Enter the first three letters or the full word.) >> ";
		cin >> dayOfWeek;

		if (cin.fail()) {
			throw runtime_error("Must be a day of the week. \n");
		}

		if (dayOfWeek == "sun" || dayOfWeek == "sunday" || dayOfWeek == "Sun" || dayOfWeek == "Sunday") {
			return 0;
		}
		else if (dayOfWeek == "mon" || dayOfWeek == "monday" || dayOfWeek == "Mon" || dayOfWeek == "Monday") {
			return 1;
		}
		else if (dayOfWeek == "tue" || dayOfWeek == "tuesday" || dayOfWeek == "Tue" || dayOfWeek == "Tuesday") {
			return 2;
		}
		else if (dayOfWeek == "wed" || dayOfWeek == "wedneday" || dayOfWeek == "Wed" || dayOfWeek == "Wednesday") {
			return 3;
		}
		else if (dayOfWeek == "thu" || dayOfWeek == "thursday" || dayOfWeek == "Thu" || dayOfWeek == "Thursday") {
			return 4;
		}
		else if (dayOfWeek == "fri" || dayOfWeek == "friday" || dayOfWeek == "Fri" || dayOfWeek == "Friday") {
			return 5;
		}
		else if (dayOfWeek == "sat" || dayOfWeek == "saturday" || dayOfWeek == "Sat" || dayOfWeek == "Saturday") {
			return 6;
		}
		else {
			cout << endl << "Invalid day of the week. \n" << endl;
		}


	} while (true);

}

int DaysPerMonth(int year, int monthNumber, int numberOfDays) {

	if (monthNumber == 1) { //28 days in February, unless it is a leap year, then there are 29 days. 
		if (numberOfDays == 366) {
			return 29;
		}
		else {
			return 28;
		}
	}
	else if ((monthNumber % 2 == 0 && monthNumber < 8) || monthNumber == 7 || (monthNumber % 2 == 1 && monthNumber >= 9)) {
		//Jan, Mar, May, Jul, Aug, Oct, Dec 
		return 31;
	}
	else {
		//Apr, Jun, Sep, Nov
		return 30;
	}

}

int IsLeapYear(int year) {
	//Takes the year number and determines if it is a leap year. 
	int numberOfDays;

	if (year % 4 == 0) {
		if (year % 100 == 0) {
			if (year % 400 == 0) {
				numberOfDays = 365;
			}
			else numberOfDays = 365;
		}
		else {
			numberOfDays = 366;
		}
	}
	else {
		numberOfDays = 365;
	}
	return numberOfDays;
}

int GetMonthStartDays(int startDayNumber, int numberOfDays, int monthStartDays[], int month, int dayCount) {
	int index;

	if (month == 0) { //January

		return startDayNumber;

	}
	else {

		return dayCount % 7;

	}

}

void PrintOneMonth(int year, int daysPerMonth, string month, int monthStartDays,  int numberOfDays) { 
	int index;
	int weekDay = monthStartDays;

	cout << right << setw(19) << month << " " << year << endl;
	cout << left << setw(0) << "Sun   Mon   Tue   Wed   Thu   Fri   Sat" << endl;
	for (index = 0; index < weekDay; ++index) {
		cout << setw(6) << " ";
	}
	for (index = 1; index <= daysPerMonth; ++index) {
		cout << setw(5) << index << " ";
		if (weekDay < 6) {
			++weekDay;
		}
		else {
			cout << endl;
			weekDay = 0;
		}
	}
	cout << endl;


}